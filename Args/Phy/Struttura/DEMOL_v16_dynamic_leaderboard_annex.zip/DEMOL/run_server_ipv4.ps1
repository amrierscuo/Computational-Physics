Set-Location -Path $PSScriptRoot
python -m http.server 8000 --bind 127.0.0.1
